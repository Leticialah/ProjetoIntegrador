# ESP32-C3 Mini + PAJ7620 + Bluetooth para iPad

Este projeto identifica gestos com o sensor PAJ7620 e envia comandos via Bluetooth BLE para um iPad.

O ESP32-C3 funciona como um teclado Bluetooth. Cada gesto envia uma tecla diferente.

## Componentes

- ESP32-C3 Mini
- Sensor de gestos PAJ7620
- Jumpers
- Cabo USB
- iPad com Bluetooth

## Ligações

| PAJ7620 | ESP32-C3 Mini |
|---|---|
| VCC | 3V3 |
| GND | GND |
| SDA | GPIO 8 |
| SCL | GPIO 9 |

Caso sua placa use outros pinos I2C, altere no arquivo `src/main.cpp`:

```cpp
#define SDA_PIN 8
#define SCL_PIN 9
```

## Comandos enviados

| Gesto | Tecla enviada |
|---|---|
| Direita | 1 |
| Esquerda | 2 |
| Cima | 3 |
| Baixo | 4 |
| Aproximar | 5 |
| Afastar | 6 |
| Horário | 7 |
| Anti-horário | 8 |

## Como abrir no VS Code

1. Instale o VS Code.
2. Instale a extensão **PlatformIO IDE**.
3. Abra esta pasta no VS Code.
4. Aguarde o PlatformIO baixar as bibliotecas.
5. Conecte o ESP32-C3 Mini no USB.
6. Clique em **Upload** no PlatformIO.
7. Abra o monitor serial em 115200 baud.

## Pareamento com o iPad

1. Grave o código no ESP32-C3.
2. No iPad, abra Bluetooth.
3. Procure por `Controle Gestos ESP32`.
4. Conecte.
5. Ao fazer gestos, o ESP32 enviará teclas para o iPad.

## Como reproduzir vídeos diferentes no iPad

O ESP32 apenas envia teclas. Para cada tecla abrir um vídeo diferente, o iPad precisa estar usando um app, site ou automação que interprete essas teclas.

Exemplo:

- Tecla `1`: reproduz vídeo 1
- Tecla `2`: reproduz vídeo 2
- Tecla `3`: reproduz vídeo 3
- Tecla `4`: reproduz vídeo 4

Uma opção é criar uma página HTML simples no iPad que escute o teclado e troque o vídeo conforme a tecla recebida.
